<?php $__env->startSection("content"); ?> 

<div class="container">
	<div class="row">
	    
	    <div class="col-md-8 col-md-offset-2">
	        
    		<h1>Edit Employee Data</h1>
    		
		<form action="/employee/edit/<?php echo e($employee->id); ?>" method="POST">
    		   
    		    <?php echo e(csrf_field()); ?>

			<div class="form-group">
				<label for="first_name">first_name<span class="require"></span></label>
				<input type="text" class="form-control" name="first_name" value="<?php echo e($employee->first_name); ?>"/>
			</div>
			
			<div class="form-group">
				<label for="last_name">last_name<span class="require"></span></label>
				<input type="text" class="form-control" name="last_name" value="<?php echo e($employee->last_name); ?>" />
			</div>
			
			<div class="form-group">
				<label for="job">job</label>
				<input type="text" class="form-control" name="job" value="<?php echo e($employee->job); ?>" />
			</div>

			<div class="form-group">
				<label for="location">location</label>
				<input type="text" class="form-control" name="location" value="<?php echo e($employee->location); ?>"/>
			</div>

			<div class="form-group">
				<label for="email">Email</label>
				<input type="text" class="form-control" name="email" value="<?php echo e($employee->email); ?>"/>
			</div>
    		    
    		    <div class="form-group">
    		        <button type="submit" class="btn btn-primary">
    		            Update
    		        </button>
    		        <button class="btn btn-default" type="reset">
    		            Cancel
    		        </button>
    		    </div>
    		    
    		</form>
		</div>
		
	</div>
</div>
<?php echo $__env->make("Layouts.Master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>