<?php $__env->startSection("content"); ?> 

<a class="nav-link" href="/post/add">Add Post <span class="sr-only">(current)</span></a>
<table class='table table-primary' >
<?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td>
            <h7> <?php echo e((DB::table('users')->find($p->user_id))->name); ?></h7>
            
        </td>
    </tr>
    <tr>
        <td>
           <h3> <a href="/post/<?php echo e($p->id); ?>"><?php echo e($p->title); ?></a></h3>
           <img src="<?php echo e(Storage::disk('local')->url($p->image)); ?>" style="width:100x; height:100px"/>

        </td>
        <td>
                <?php echo e($p->created_at->diffForHumans()); ?>

        </td>
    </tr>
    
    <tr>
        <td>
            <a href="/post/edit/<?php echo e($p->id); ?>"><button class="btn btn-primary">
                Edit
            </button></a>
        
            <a href="/post/delete/<?php echo e($p->id); ?>"><button class="btn btn-danger">
                Delete
            </button></a>
        </td>

    </tr>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?> 

<?php echo $__env->make("Layouts.Master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>