<?php $__env->startSection("content"); ?> 

<h2 style="color:#00ACC1"><?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?></h2>
<h5><?php echo e($employee->job); ?></h5>





	<div class="form-group">
		<?php if(count($errors)): ?>
			<div class='alert alert-danger'>
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>

			</div>
		<?php endif; ?>

	</div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make("Layouts.Master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>