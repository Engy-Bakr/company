<?php $__env->startSection("content"); ?> 

<a class="nav-link" href="/employee/add">Add Employee <span class="sr-only">(current)</span></a>
<table class='table table-primary' >
<?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td>
           <h3> <a href="/employee/<?php echo e($e->id); ?>"><?php echo e($e->first_name); ?> <?php echo e($e->last_name); ?></a></h3>
           <img src="<?php echo e(Storage::url($e->image)); ?>" style="width:100x; height:100px"/>

        </td>
    </tr>
  
    <tr>
        <td>
            <a href="/employee/edit/<?php echo e($e->id); ?>"><button class="btn btn-primary">
                Edit
            </button></a>
        
            <a href="/employee/delete/<?php echo e($e->id); ?>"><button class="btn btn-danger">
                Delete
            </button></a>
        </td>

    </tr>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?> 

<?php echo $__env->make("Layouts.Master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>