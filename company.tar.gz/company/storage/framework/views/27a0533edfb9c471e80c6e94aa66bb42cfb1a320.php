<?php $__env->startSection("content"); ?> 
<br><br>
<div class="container">
	<div class="row">
	    
	    <div class="col-md-8 col-md-offset-2">
	        
    		<h1>Add Employee</h1>
    		
    		<form action="/employee/add" method="POST" enctype="multipart/form-data">
    		   
    		    <?php echo e(csrf_field()); ?>

    		    <div class="form-group">
    		        <label for="first_name">first_name<span class="require"></span></label>
    		        <input type="text" class="form-control" name="first_name" />
				</div>
				
				<div class="form-group">
    		        <label for="last_name">last_name<span class="require"></span></label>
    		        <input type="text" class="form-control" name="last_name" />
    		    </div>
    		    
    		    <div class="form-group">
    		        <label for="job">job</label>
    		        <input type="text" class="form-control" name="job" />
				</div>

				<div class="form-group">
    		        <label for="location">location</label>
    		        <input type="text" class="form-control" name="location" />
				</div>

				<div class="form-group">
					<label for="email">Email</label>
					<input type="email" class="form-control" name="email"/>
				</div>
				

				<div class="form-group">
						<label for="image">upload image</label>
						<input class="form-control" name="image" type="file"/>
				</div>

			
    		  
    		    
    		    <div class="form-group">
    		        <button type="submit" class="btn btn-primary">
    		            Create
    		        </button>
    		        <button class="btn btn-default" type="reset">
    		            Cancel
    		        </button>
    		    </div>
    		    
    		</form>
		</div>
		
	</div>
</div>
<?php echo $__env->make("Layouts.Master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>