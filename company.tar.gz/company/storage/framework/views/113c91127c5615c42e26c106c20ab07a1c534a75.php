<?php $__env->startSection("content"); ?>
<style>
    #bottom {
        width:400px;
        height:200px;
        /* background-color:  rgb(224, 174, 184); */
        -webkit-box-flex: 1;
        text-align: center; 
        margin-left: 20px;
    }
</style>
<script async defer
   src="https://maps.googleapis.com/maps/api/js?libraries=places&key= AIzaSyBmnATbcsItV07AIzYhG-6E0ZYgZgTkh3w"></script>
    <script>
         var lat, lon,time,acc;
       window.addEventListener('load', doitfirst);
        function doitfirst() {
            map = document.getElementById("bottom");
        }

        function getmyposition() {
            if(navigator.geolocation)
            {
                navigator.geolocation.getCurrentPosition(getposition, errorhandeler);
            }
            else
            {
                map.innerText = "sorry, update your browser";
            } 
        
        }
        function getposition(position)
        {
            map.style.display="inline-block";
            lat = position.coords.latitude;
            lon = position.coords.longitude;
            time = position.timestamp;
            acc = position.coords.accuracy;
            mylocation = new google.maps.LatLng(lat,lon);
            myattribute = { zoom: 17, center: mylocation };
            // var myimg = new Image();
            var myimg = new google.maps.Map( map, myattribute);
            // map.appendChild(myimg);
            var marker = new google.maps.Marker({
                position: mylocation ,
                title:"Hello World!"
            });

            // To add the marker to the map, call setMap();
             marker.setMap(myimg);

	    document.getElementsByTagName("input")[3].value=mylocation;

            
        }
        function errorhandeler(error)
        {
            switch(error.code)
            {
                case error.PERMISSION_DENIED:
                    map.innerText = 'PERMISSION_DENIED';
                    break;
                case error.POSITION_UNAVAILABLE:
                    map.innerText = 'POSITION_UNAVAILABLE';
                    break;
                case error.TIMEOUT:
                    map.innerText = 'TIMEOUT';
                    break;
                case error.UNKOWN_ERROR:
                    map.innerText = 'UNKOWN_ERROR';
                    break;
            }
        }
  
</script>

 
<br><br>
<div class="container">
	<div class="row">
	    
	    <div class="col-md-8 col-md-offset-2">
	        
    		<h1>Add Employee</h1>
    		
    		<form action="/employee/add" method="POST" enctype="multipart/form-data">
    		   
    		    <?php echo e(csrf_field()); ?>

    		    <div class="form-group">
    		        <label for="first_name">first_name<span class="require"></span></label>
    		        <input type="text" class="form-control" name="first_name" />
				</div>
				
				<div class="form-group">
    		        <label for="last_name">last_name<span class="require"></span></label>
    		        <input type="text" class="form-control" name="last_name" />
    		    </div>
    		    
    		    <div class="form-group">
    		        <label for="job">job</label>
    		        <input type="text" class="form-control" name="job" />
				</div>

		    <div class="form-group">
    		        <label for="location">location</label>
			<section id="top">
        		        <button class="btn btn_primary" onclick="getmyposition();"/>Location
        		</section>
			<section id="bottom"></section>
    		        <input type="text" class="form-control" name="location" />
		    </div>

				<div class="form-group">
					<label for="email">Email</label>
					<input type="email" class="form-control" name="email"/>
				</div>
				

				<div class="form-group">
						<label for="image">upload image</label>
						<input class="form-control" name="image" type="file"/>
				</div>    		  
    		    
    		    <div class="form-group">
    		        <button type="submit" class="btn btn-primary">
    		            Create
    		        </button>
    		        <button class="btn btn-default" type="reset">
    		            Cancel
    		        </button>
    		    </div>
    		    
    		</form>
		</div>
		
	</div>
</div>

<?php echo $__env->make("Layouts.Master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>