
<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('Layouts.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

    <div class="contaner">
        @yelid("content")
    </div>
    
</body>
</html>