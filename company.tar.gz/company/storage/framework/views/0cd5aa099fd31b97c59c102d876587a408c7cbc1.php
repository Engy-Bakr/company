<?php $__env->startSection("content"); ?> 

<h2 style="color:#00ACC1"><?php echo e($post->title); ?></h2>
<h5><?php echo e($post->content); ?></h5>


<table class='form-groub table'>
	<h4 style="color:#00ACC1">comments</h4>
	<?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td>
				<h4 style="color:#007CC1" > <?php echo e($c->title); ?></h4>
				<h7><?php echo e($c->body); ?><h7>
			</td>
		
			<td>
				<?php echo e($c->created_at->diffForHumans()); ?>

			</td>
		</tr>
	
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<div class="container">
	<div class="row">
	    
	    <div class="col-md-8 col-md-offset-2">
	        
    		<h7>Add Comment</h7>
    		
		<form action="<?php echo e($post->id); ?>/comment" method="POST" style="background:#E0F7FA" class="form-control">
    		   
    		    <?php echo e(csrf_field()); ?>

    		    <div class="form-group">
    		        <label for="title">Title <span class="require"></span></label>
    		        <input type="text" class="form-control" name="title" />
    		    </div>
    		    
    		    <div class="form-group">
    		        <label for="description">Comment</label>
    		        <textarea rows="2" class="form-control" name="body" ></textarea>
				</div>
			  
    		    
    		    <div class="form-group">
    		        <button type="submit" class="btn btn-primary">
    		            Add
    		        </button>
    		        
    		    </div>
    		    
    		</form>
		</div>
		
	</div>
	<div class="form-group">
		<?php if(count($errors)): ?>
			<div class='alert alert-danger'>
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>

			</div>
		<?php endif; ?>

	</div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make("Layouts.Master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>