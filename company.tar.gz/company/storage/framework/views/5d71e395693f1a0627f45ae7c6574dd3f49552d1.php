<?php $__env->startSection("content"); ?> 

<div class="container">
	<div class="row">
	    
	    <div class="col-md-8 col-md-offset-2">
	        
    		<h1>Create post</h1>
    		
		<form action="<?php echo e(route('posts.edit',$post->id)); ?>" method="POST">
    		   
    		    <?php echo e(csrf_field()); ?>

    		    <div class="form-group">
    		        <label for="title">Title <span class="require"></span></label>
    		        <input type="text" class="form-control" name="title" value="<?php echo e($post->title); ?>"/>
    		    </div>
    		    
    		    <div class="form-group">
    		        <label for="description">Description</label>
    		        <textarea rows="5" class="form-control" name="content" ><?php echo e($post->content); ?></textarea>
    		    </div>
    		  
    		    
    		    <div class="form-group">
    		        <button type="submit" class="btn btn-primary">
    		            Update
    		        </button>
    		        <button class="btn btn-default" type="reset">
    		            Cancel
    		        </button>
    		    </div>
    		    
    		</form>
		</div>
		
	</div>
</div>
<?php echo $__env->make("Layouts.Master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>