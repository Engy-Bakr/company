<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
           
            <div class="panel panel-default">
                
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

              
<a class="nav-link" href="/post/add " style="color:red; font-size:25px">Add Post <span class="sr-only">(current)</span></a>
<table class='table table-primary' >
<?php $__currentLoopData = Auth::user()->post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td>
            <h4 style="color:#007CC1"> <?php echo e(Auth::user()->name); ?></h4>
            
        </td>
    </tr>
    <tr>
        
        <td>
           <h3> <a href="/post/<?php echo e($p->id); ?>"><?php echo e($p->title); ?></a></h3>
           <img src="<?php echo e(Storage::disk('local')->url($p->image)); ?>" style="width:100x; height:100px"/>

        </td>
        <td>
                <?php echo e($p->created_at->diffForHumans()); ?>

        </td>
    </tr>
  
    <tr>
        <td>
            <a href="/post/edit/<?php echo e($p->id); ?>"><button class="btn btn-primary">
                Edit
            </button></a>
        
            <a href="/post/delete/<?php echo e($p->id); ?>"><button class="btn btn-danger">
                Delete
            </button></a>
        </td>

    </tr>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table> 
                   

                    You are logged in!
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>