<?php $__env->startSection("content"); ?> 

<table>
<?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td>
            <a href="<?php echo e($p->id); ?>"><?php echo e($p->title); ?></a>
        </td>
        <td>
                <?php echo e($p->created_at->diffForHumans()); ?>

        </td>
        <td>
            <img src="<?php echo e(Storage::disk('local')->url($p->image)); ?>" style="width:50x; height:50px"/>
        </td>
        <td>
            <a href="edit/<?php echo e($p->id); ?>"><button class="btn btn-primary">
                Edit
            </button></a>
        </td>
        <td>    
            <a href="delete/<?php echo e($p->id); ?>"><button class="btn btn-danger">
                Delete
            </button></a>
        </td>

    </tr>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?> 

<?php echo $__env->make("Layouts.Master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>