<?php

namespace App\Http\Controllers;


use App\employee;
use App\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class employeeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $employee=employee::all();
        return view('employee.home',compact('employee'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('employee.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //

        $imagename='';

        if($request->hasFile('image')){
            //$imagename=$request->image->getClientOrigionalName();
            $imagename=$request->file('image')->store('public');
        }

        $this->validate(request(),[
            'first_name'=>'required|min:2',
            'last_name'=>'required|min:2' ,
            'job'=>'required|min:2',
            'location'=>'required|min:2',
        ]);


        $user=new user;
        $user->name=$request->first_name.$request->last_name;
        $user->email=$request->email;
        $user->password=$request->email;
        $user->admin="0";
        $user->save();


        $employee=new employee;
        $employee->first_name=$request->first_name;
        $employee->last_name=$request->last_name;
        $employee->job=$request->job;
        $employee->location=$request->location;
        $employee->email=$request->email;
        $employee->user_id=$user->id; 
        $employee->image=$imagename;
        $employee->save();

        $employee=employee::all();
        return view('employee.home',compact('employee'));
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function show(employee $employee)
    {
       // $post=Post::find($id);
    

        return view('employee.details',compact('employee'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function edit(employee $employee)
    {
        //
        // $post=Post::find($id);
        return view('employee.edit',compact('employee'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, employee $employee)
    {
        //
        $employee->first_name=$request->first_name;
        $employee->last_name=$request->last_name;    
        $employee->job=$request->job; 
        $employee->location=$request->location;     
        $employee->save();
       // return redirect()->back();
       return redirect('employee');


    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function destroy(employee $employee)
    {
        //
        $employee->delete($employee);
        $employee=employee::all();
        return view('employee.home',compact('employee'));
        //return view('posts.list');
    }
}
