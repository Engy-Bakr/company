<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class employee extends Model
{
    //
    // public function comments(){

    //     return $this->hasMany(comment::class);
        
    // }
    // public function user(){
    //     return $this->hasOne(User::class);
    // }
}
