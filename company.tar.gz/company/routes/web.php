<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', function () {
    return view('welcome');
});


Route::get('employee/add','employeeController@create');

Route::post('employee/add','employeeController@store');

Route::get('employee','employeeController@index');

Route::get('employee/{employee}','employeeController@show');

Route::get('employee/edit/{employee}','employeeController@edit');

Route::post('employee/edit/{employee}','employeeController@update')->name('posts.edit');

Route::get('employee/delete/{employee}','employeeController@destroy');

Auth::routes();





//Route::resource('posts','PostController');





Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
