@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
           
            <div class="panel panel-default">
                
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

              
<a class="nav-link" href="/employee/add " style="color:red; font-size:25px"> Add Employee <span class="sr-only">(current)</span></a>
{{-- <table class='table table-primary' >
@foreach( Auth::user()->post as $key =>$p)
    <tr>
        <td>
            <h4 style="color:#007CC1"> {{Auth::user()->name}}</h4>
            
        </td>
    </tr>
    <tr>
        
        <td>
           <h3> <a href="/post/{{$p->id}}">{{$p->title}}</a></h3>
           <img src="{{Storage::disk('local')->url($p->image)}}" style="width:100x; height:100px"/>

        </td>
        <td>
                {{$p->created_at->diffForHumans()}}
        </td>
    </tr>
  
    <tr>
        <td>
            <a href="/post/edit/{{$p->id}}"><button class="btn btn-primary">
                Edit
            </button></a>
        
            <a href="/post/delete/{{$p->id}}"><button class="btn btn-danger">
                Delete
            </button></a>
        </td>

    </tr>


@endforeach
</table>  --}}
                   
                <div>
                    You are logged in!
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
