@extends("Layouts.Master")
@section("content") 

<h2 style="color:#00ACC1">{{$employee->first_name}} {{$employee->last_name}}</h2>
<h5>{{$employee->job}}</h5>
<h5>{{$employee->location}}</h5>



	<div class="form-group">
		@if (count($errors))
			<div class='alert alert-danger'>
				<ul>
					@foreach ($errors->all() as $key=>$error)
						<li>{{$error}}</li>
					@endforeach
				</ul>

			</div>
		@endif

	</div>
</div>
@endsection 