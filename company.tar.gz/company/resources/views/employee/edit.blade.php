@extends("Layouts.Master")
@section("content") 

<div class="container">
	<div class="row">
	    
	    <div class="col-md-8 col-md-offset-2">
	        
    		<h1>Edit Employee Data</h1>
    		
		<form action="/employee/edit/{{$employee->id}}" method="POST">
    		   
    		    {{csrf_field()}}
			<div class="form-group">
				<label for="first_name">first_name<span class="require"></span></label>
				<input type="text" class="form-control" name="first_name" value="{{$employee->first_name}}"/>
			</div>
			
			<div class="form-group">
				<label for="last_name">last_name<span class="require"></span></label>
				<input type="text" class="form-control" name="last_name" value="{{$employee->last_name}}" />
			</div>
			
			<div class="form-group">
				<label for="job">job</label>
				<input type="text" class="form-control" name="job" value="{{$employee->job}}" />
			</div>

			<div class="form-group">
				<label for="location">location</label>
				<input type="text" class="form-control" name="location" value="{{$employee->location}}"/>
			</div>

			<div class="form-group">
				<label for="email">Email</label>
				<input type="text" class="form-control" name="email" value="{{$employee->email}}"/>
			</div>
    		    
    		    <div class="form-group">
    		        <button type="submit" class="btn btn-primary">
    		            Update
    		        </button>
    		        <button class="btn btn-default" type="reset">
    		            Cancel
    		        </button>
    		    </div>
    		    
    		</form>
		</div>
		
	</div>
</div>