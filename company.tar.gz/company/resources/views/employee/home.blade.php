@extends("Layouts.Master")
@section("content") 

<a class="nav-link" href="/employee/add">Add Employee <span class="sr-only">(current)</span></a>
<table class='table table-primary' >
@foreach($employee as $e)
    <tr>
        <td>
           <h3> <a href="/employee/{{$e->id}}">{{$e->first_name}} {{$e->last_name}}</a></h3>
           <img src="{{Storage::url($e->image)}}" style="width:100x; height:100px"/>

        </td>
    </tr>
  
    <tr>
        <td>
            <a href="/employee/edit/{{$e->id}}"><button class="btn btn-primary">
                Edit
            </button></a>
        
            <a href="/employee/delete/{{$e->id}}"><button class="btn btn-danger">
                Delete
            </button></a>
        </td>

    </tr>


@endforeach
</table>
@endsection 
