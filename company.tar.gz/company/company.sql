-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 18, 2018 at 10:31 AM
-- Server version: 5.7.21-0ubuntu0.16.04.1
-- PHP Version: 7.0.28-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `company`
--

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(10) UNSIGNED NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `job` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `first_name`, `last_name`, `job`, `image`, `user_id`, `location`, `email`, `created_at`, `updated_at`) VALUES
(7, 'sara', 'ashraf', 'ios', '', 13, 'masss', 'sara@yahoo.com', '2018-04-17 08:59:21', '2018-04-17 08:59:21'),
(8, 'sdfg', 'sdfghj', 'xcfghjm', 'public/bDMJGtjfGncUvZDomEUDYVTb01Cg8LW2xsrirLRm.png', 14, 'cvbm,', 'sdfghgf@bbbb.com', '2018-04-17 08:59:47', '2018-04-17 08:59:47'),
(9, 'mohamed', 'ashraf', 'php developer', 'public/ORB7XgjkTd7hERsdloFplcrh5biNfAKjmsLT47Sg.png', 15, 'cairo', 'ashraf@yahoo.com', '2018-04-17 09:02:21', '2018-04-17 09:02:21');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(7, '2014_10_12_000000_create_users_table', 1),
(8, '2014_10_12_100000_create_password_resets_table', 1),
(9, '2018_04_04_111826_create_employee_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin` int(11) NOT NULL DEFAULT '1',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `admin`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'engy  bakr', 'enjy.bakr@yahoo.com', '$2y$10$Jl84XDhSfabrCt2Wocdw/.Q78jE5sXdW.CjlPeJUswAPWHcEIJZrm', 1, NULL, '2018-04-17 06:50:53', '2018-04-17 06:50:53'),
(2, 'Engybakr', 'engy.bakr@yahoo.com', 'engy.bakr@yahoo.com', 0, NULL, '2018-04-17 07:00:36', '2018-04-17 07:00:36'),
(4, 'HossamMahmoud', 'hossam@mail.com', 'hossam@mail.com', 0, NULL, '2018-04-17 07:25:12', '2018-04-17 07:25:12'),
(5, 'lamiaaazeh', 'lamiaa@gmail.com', 'lamiaa@gmail.com', 0, NULL, '2018-04-17 07:59:52', '2018-04-17 07:59:52'),
(7, 'asdasd', 'asd@s.com', 'asd@s.com', 0, NULL, '2018-04-17 08:17:46', '2018-04-17 08:17:46'),
(9, 'eeee', 'a@aaa.com', 'a@aaa.com', 0, NULL, '2018-04-17 08:22:42', '2018-04-17 08:22:42'),
(11, 'aaaaa', 'a@a.com', 'a@a.com', 0, NULL, '2018-04-17 08:26:17', '2018-04-17 08:26:17'),
(12, 'asdasd', 'enjybakdddr@yahoo.com', 'enjybakdddr@yahoo.com', 0, NULL, '2018-04-17 08:46:53', '2018-04-17 08:46:53'),
(13, 'saraashraf', 'sara@yahoo.com', 'sara@yahoo.com', 0, NULL, '2018-04-17 08:59:21', '2018-04-17 08:59:21'),
(14, 'sdfgsdfghj', 'sdfghgf@bbbb.com', 'sdfghgf@bbbb.com', 0, NULL, '2018-04-17 08:59:47', '2018-04-17 08:59:47'),
(15, 'mohamedashraf', 'ashraf@yahoo.com', 'ashraf@yahoo.com', 0, NULL, '2018-04-17 09:02:21', '2018-04-17 09:02:21');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
